<html>
    <head>
        <title>Cadastro de cidade</title>
    </head>
    <body>
        <form>
            <label for='campo_id'>id</label>
<input type='text' name='campo_id'><br>
<label for='campo_nome'>nome</label>
<input type='text' name='campo_nome'><br>
<label for='campo_habitantes'>habitantes</label>
<input type='text' name='campo_habitantes'><br>
<label for='campo_id_estado'>id_estado</label>
<input type='text' name='campo_id_estado'><br>

        </form>
    </body>
</html>