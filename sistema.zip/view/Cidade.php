<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cadastro deCidade</title>
</head>
<body>
    <h1>Cadastro de Cidade</h1>
    <form>
        <label for='id'>Id:</label>
<input type='text' id='id' name='id'><br>
<label for='nome'>Nome:</label>
<input type='text' id='nome' name='nome'><br>
<label for='habitantes'>Habitantes:</label>
<input type='text' id='habitantes' name='habitantes'><br>
<label for='id_estado'>Id_estado:</label>
<input type='text' id='id_estado' name='id_estado'><br>

    </form>
</body>
</html>