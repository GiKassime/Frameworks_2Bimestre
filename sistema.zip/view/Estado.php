<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cadastro deEstado</title>
</head>
<body>
    <h1>Cadastro de Estado</h1>
    <form>
        <label for='id'>Id:</label>
<input type='text' id='id' name='id'><br>
<label for='nome'>Nome:</label>
<input type='text' id='nome' name='nome'><br>
<label for='sigla'>Sigla:</label>
<input type='text' id='sigla' name='sigla'><br>

    </form>
</body>
</html>