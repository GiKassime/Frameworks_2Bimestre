<html>
    <head>
        <title>Cadastro de estado</title>
    </head>
    <body>
        <form>
            <label for='campo_id'>id</label>
<input type='text' name='campo_id'><br>
<label for='campo_nome'>nome</label>
<input type='text' name='campo_nome'><br>
<label for='campo_sigla'>sigla</label>
<input type='text' name='campo_sigla'><br>

        </form>
    </body>
</html>