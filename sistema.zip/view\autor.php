<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <title>Cadastro de autor</title>
    <link rel="stylesheet" href="./../styles/views.css">
</head>
<body>
    <form> 
        <h1>Cadastro de autor</h1>
        <label for='campo_id'>id</label>
<input type='number' name='campo_id' id='campo_id'><br>
<label for='campo_nome'>nome</label>
<input type='text' name='campo_nome' id='campo_nome'><br>
<label for='campo_nacionalidade'>nacionalidade</label>
<input type='text' name='campo_nacionalidade' id='campo_nacionalidade'><br>

        <button type="submit">Enviar</button>
    </form>
</body>
</html>