<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <title>Cadastro de categoria</title>
    <link rel="stylesheet" href="./../styles/views.css">
</head>
<body>
    <form> 
        <h1>Cadastro de categoria</h1>
        <label for='campo_id'>id</label>
<input type='number' name='campo_id' id='campo_id'><br>
<label for='campo_descricao'>descricao</label>
<input type='text' name='campo_descricao' id='campo_descricao'><br>

        <button type="submit">Enviar</button>
    </form>
</body>
</html>